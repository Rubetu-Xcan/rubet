pkg install python2
pip install requests
pip install mechanize
pkg install zip
pkg install unzip
unzip phising.zip
cd phising
python2 log.py
